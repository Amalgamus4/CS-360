package com.zybooks.inventoryappryanwardcs360.repo;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.zybooks.inventoryappryanwardcs360.model.InventoryItem;

import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {

    // This is a singleton database for storing inventory items
    // Note: passwords are stored in plain text, which is bad practice
    // Future iterations would evolve to hash passwords
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;
    private static InventoryDatabase mInventoryDatabase;

    // Singleton pattern
    public static InventoryDatabase getInstance(Context context) {
        if (mInventoryDatabase == null) {
            mInventoryDatabase = new InventoryDatabase(context.getApplicationContext());
        }
        return mInventoryDatabase;
    }
    private InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Values for inventory table
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM = "item";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QTY = "quantity";
    }

    // Values for users table
    private static final class UsersTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    // Create tables in database
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEM + " text, " +
                InventoryTable.COL_DESCRIPTION + " text, " +
                InventoryTable.COL_QTY + " int)");

        db.execSQL("create table " + UsersTable.TABLE + " (" +
                UsersTable.COL_ID + " integer primary key autoincrement, " +
                UsersTable.COL_USERNAME + " text, " +
                UsersTable.COL_PASSWORD + " text)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    public InventoryItem getItem(long id) {
        // Returns the inventory item if found, or an empty item if not found
        SQLiteDatabase db = getReadableDatabase();
        InventoryItem item;
        String sql = "select * from " + InventoryTable.TABLE + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {Float.toString(id)});
        if (cursor.moveToFirst()) {
                long itemId = cursor.getLong(0);
                String itemName = cursor.getString(1);
                String description = cursor.getString(2);
                int qty = cursor.getInt(3);
                Log.d(TAG, "Item = " + itemId + ", " + itemName + ": " + qty);
                item = new InventoryItem(itemId, itemName, description, qty);
        }
        else {item = new InventoryItem();}
        cursor.close();
        return item;
    }
    public long addItem(String item, String description, int qty) {
        // Returns the id of the inserted row, or -1 if insert failed
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEM, item);
        values.put(InventoryTable.COL_DESCRIPTION, description);
        values.put(InventoryTable.COL_QTY, qty);

        return (db.insert(InventoryTable.TABLE, null, values));
    }

    public ArrayList<InventoryItem> getInventoryList(){
        // Returns the full list of inventory items for populating the main grid
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<InventoryItem> itemList = new ArrayList<>();

        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String itemName = cursor.getString(1);
                String description = cursor.getString(2);
                int qty = cursor.getInt(3);
                Log.d(TAG, "Item = " + id + ", " + itemName + ": " + qty);
                InventoryItem item = new InventoryItem(id, itemName, description, qty);
                itemList.add(item);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }

    public boolean updateItem(long id, String item, String description) {
        // Returns true if item was successfully updated, false otherwise
        // Used to update the item name and description (Edit Item Fragment)
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEM, item);
        values.put(InventoryTable.COL_DESCRIPTION, description);

        int rowsUpdated = db.update(InventoryTable.TABLE, values, "_id = ?",
                new String[] {Float.toString(id)});
        return rowsUpdated > 0;
    }

    public void updateItem(long id, int qty) {
        // Used to update just the quantity (Details Fragment)
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QTY, qty);

        db.update(InventoryTable.TABLE, values, "_id = ?",
                new String[] {Float.toString(id)});
    }

    public boolean deleteItem(long id) {
        // Returns true if row successfully deleted, false otherwise
        // Used to delete item from database (Edit Item Fragment)
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " =  ?",
                new String[] {Long.toString(id)});
        return rowsDeleted > 0;
    }

    public long addUser(String username, String password) {
        // Returns id of user entry, or -1 if failed
        // Used to add new user to database (New Account Fragment)
        if (userExists(username)) {
            return -2; // -1 reserved for failures
        }
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_USERNAME, username);
        values.put(UsersTable.COL_PASSWORD, password);

        return db.insert(UsersTable.TABLE, null, values);
    }

    public boolean loginValid(String username, String password) {
        // Checks for existing user and then checks for correct password
        if (userExists(username)) {
            return passwordCorrect(username, password);
        }
        return false;
    }

    public boolean userExists(String username) {
        // Searches for existing user to prevent duplicate accounts
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select _id, username from " + UsersTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username});
        if (cursor.moveToFirst()) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;
    }

    private boolean passwordCorrect(String username, String password) {
        // Checks for entry in users table that matches username and password
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UsersTable.TABLE + " where username = ? and password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});
        if (cursor.moveToFirst()) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;
    }
}
