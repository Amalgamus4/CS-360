package com.zybooks.inventoryappryanwardcs360;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.preference.PreferenceManager;

import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.zybooks.inventoryappryanwardcs360.model.InventoryItem;
import com.zybooks.inventoryappryanwardcs360.repo.InventoryDatabase;

public class DetailsFragment extends Fragment {
    private InventoryDatabase mInventoryDatabase;

    public DetailsFragment() {super(R.layout.fragment_details);}
    private long id;
    private int qty;
    private Context mContext;
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (!isGranted) {
                    Toast.makeText(mContext, "Permission denied. Cannot send SMS.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get shared preferences and check if SMS enabled in settings
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        boolean isSmsEnabled = preferences.getBoolean("smsEnabled", false);

        // Button to return to main grid (back button should work, too)
        view.findViewById(R.id.button_return_to_list).setOnClickListener(v ->
                Navigation.findNavController(view)
                        .navigate(R.id.action_DetailsFragment_to_MainGridFragment));

        // Make sure back button navigates from details back to main grid
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Navigation.findNavController(view).navigate(R.id.action_DetailsFragment_to_MainGridFragment);
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), callback);

        // Get singleton database
        mInventoryDatabase = InventoryDatabase.getInstance(requireContext());
        if (getArguments() != null) {
            id = getArguments().getLong("ITEM_ID", -1);
        }
        else {
            id = -1;
        }

        // Setup views and buttons from layout file
        TextView viewName = view.findViewById(R.id.tv_item_name);
        TextView viewDescription = view.findViewById(R.id.tv_description);
        EditText editQty = view.findViewById(R.id.et_quantity);
        Button btnEditItem = view.findViewById(R.id.button_edit_info);
        FloatingActionButton btnIncrease = view.findViewById(R.id.fab_increase_qty);
        FloatingActionButton btnDecrease = view.findViewById(R.id.fab_decrease_qty);

        // Update view items if item found
        if (id != -1) {
            InventoryItem mItem = mInventoryDatabase.getItem(id);
            viewName.setText(mItem.getItemName());
            viewDescription.setText(mItem.getItemDescription());
            qty = mItem.getQuantity();
            editQty.setText(String.valueOf(qty));
        }

        editQty.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    qty = Integer.parseInt(s.toString());
                }
                else { qty = 0; }
                mInventoryDatabase.updateItem(id, qty);
                // Send SMS when quantity is set to zero
                if (qty == 0 && isSmsEnabled) {
                    checkPermissionsAndSendMessage();
                }
            }
        });

        // Increase quantity
        btnIncrease.setOnClickListener(v -> {
            if (id != -1) {
                qty++;
                mInventoryDatabase.updateItem(id, qty);
                editQty.setText(String.valueOf(qty));
            }
        });

        // Decrease quantity
        btnDecrease.setOnClickListener(v -> {
            if (id != -1) {
                qty--;
                mInventoryDatabase.updateItem(id, qty);
                editQty.setText(String.valueOf(qty));
                if (qty == 0 && isSmsEnabled) {
                    checkPermissionsAndSendMessage();
                }
            }
        });

        // Navigate to Edit Item Fragment, passing item's ID
        btnEditItem.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putLong("ITEM_ID", id);
            Navigation.findNavController(view).navigate(R.id.action_DetailsFragment_to_EditItemFragment, bundle);
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // For getting the necessary context to check permissions
        mContext = context;
    }

    public void checkPermissionsAndSendMessage() {
        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            String msg = "Item: " + mInventoryDatabase.getItem(id).getItemName() + "has zero quantity.";
            sendSms(msg);
        }
        else {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void sendSms(String message) {
        // The toast in the app indicates this method worked, but I never saw an actual text come through the emulator
        SmsManager smsManager = SmsManager.getDefault();
        String smsNumber = "5554";
        smsManager.sendTextMessage(smsNumber, null, message, null, null);
        Toast.makeText(mContext, "Message sent", Toast.LENGTH_LONG).show();
    }
}