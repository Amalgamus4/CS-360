package com.zybooks.inventoryappryanwardcs360;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {

    public SettingsFragment() {super(R.layout.fragment_settings);}

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get shared preferences
        SharedPreferences preferences = requireActivity().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        // Get toggle button from settings fragment
        ToggleButton btnSmsEnable = view.findViewById(R.id.smsEnableToggle);

        // Set toggle to saved value from shared preferences, or false if not yet saved
        btnSmsEnable.setChecked(preferences.getBoolean("smsEnabled", false));
        btnSmsEnable.setOnClickListener(v -> {
            // Save toggle value to preferences any time it is changed (no save button needed)
            editor.putBoolean("smsEnabled", btnSmsEnable.isChecked());
            editor.apply();
        });
    }
}