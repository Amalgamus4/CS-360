package com.zybooks.inventoryappryanwardcs360;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventoryappryanwardcs360.model.InventoryItem;
import com.zybooks.inventoryappryanwardcs360.repo.InventoryDatabase;

import java.util.ArrayList;

public class MainGridFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main_grid, container, false);

        // Listener that gets ID of clicked item and passes to details fragment
        View.OnClickListener onClickListener = itemView -> {
            long selectedItemId = (long) itemView.getTag();
            Bundle args = new Bundle();
            args.putLong("ITEM_ID", selectedItemId);
            Navigation.findNavController(itemView).navigate(R.id.action_MainGridFragment_to_DetailsFragment, args);
        };

        // Menu inflater to access settings
        // Note: I have no idea why settings is listed twice, but it still works
        Toolbar toolbar = view.findViewById(R.id.toolbar);
        toolbar.inflateMenu(R.menu.menu_main);
        // Menu list listener
        toolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.settings_menu_item) {
                // Navigation for settings fragment
                NavHostFragment.findNavController(MainGridFragment.this)
                        .navigate(R.id.action_MainGridFragment_to_SettingsFragment);
                return true;
            }
            return false;
        });

        // Get recycler view from layout
        RecyclerView mRecyclerView = view.findViewById(R.id.inventory_recycler_view);

        // Add divider between items in recycler view
        DividerItemDecoration divider = new DividerItemDecoration(mRecyclerView.getContext(),
                DividerItemDecoration.VERTICAL);
        mRecyclerView.addItemDecoration(divider);

        // Get list of all items in database
        ArrayList<InventoryItem> itemsList = InventoryDatabase.getInstance(requireContext()).getInventoryList();

        // Set adapter for recycler view
        mRecyclerView.setAdapter(new ItemAdapter(itemsList, onClickListener));

        // Set listener to add new item
        view.findViewById(R.id.fab_add_new_item).setOnClickListener(v -> addNewItemClick());
        return view;
    }

    private void addNewItemClick() {
        if (getView() != null) {
            // Navigate to Edit Item Fragment
            Navigation.findNavController(getView()).navigate(R.id.action_MainGridFragment_to_NewItemFragment);
        }
    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {
        // This adapter takes the inventory items list and binds each item to an item holder
        private final ArrayList<InventoryItem> itemList;
        private final View.OnClickListener mOnClickListener;

        public ItemAdapter(ArrayList<InventoryItem> itemList, View.OnClickListener onClickListener) {
            this.itemList = itemList;
            this.mOnClickListener = onClickListener;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull ItemHolder holder, int position) {
            InventoryItem item = itemList.get(position);
            holder.bind(item);
            holder.itemView.setTag(item.getId());
            holder.itemView.setOnClickListener(mOnClickListener);
        }

        @Override
        public int getItemCount() {
            return itemList.size();
        }
    }

    private static class ItemHolder extends RecyclerView.ViewHolder {
        // This holder applies the inventory_item layout to individual items
        private final TextView mItemTextView;
        private final TextView mQuantityTextView;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.inventory_item, parent, false));
            mItemTextView = itemView.findViewById(R.id.tv_item_name);
            mQuantityTextView = itemView.findViewById(R.id.tv_quantity);
        }
        public void bind(InventoryItem item) {
            mItemTextView.setText(item.getItemName());
            mQuantityTextView.setText(String.valueOf(item.getQuantity()));
        }
    }
}