package com.zybooks.inventoryappryanwardcs360;

import android.app.AlertDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zybooks.inventoryappryanwardcs360.model.InventoryItem;
import com.zybooks.inventoryappryanwardcs360.repo.InventoryDatabase;

public class EditItemFragment extends Fragment {
    private InventoryDatabase mInventoryDatabase;

    public EditItemFragment() {super(R.layout.fragment_edit_item);}
    private long id;
    private final int DEFAULT_QTY = 0;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get singleton database
        mInventoryDatabase = InventoryDatabase.getInstance(requireContext());
        // Get id of item from bundle
        if (getArguments() != null) {
            id = getArguments().getLong("ITEM_ID");
        }
        else {
            id = -1;
            // If adding new item, there is no ID, and we hide the delete button
            view.findViewById(R.id.button_delete_item).setVisibility(View.GONE);
        }

        // Setup views and buttons
        EditText editName = view.findViewById(R.id.tv_item_name);
        EditText editDescription = view.findViewById(R.id.tv_description);
        Button btnSave = view.findViewById(R.id.button_save_item);
        Button btnDelete = view.findViewById(R.id.button_delete_item);

        // Populate values if editing existing item
        if (getArguments() != null) {
            InventoryItem mItem = mInventoryDatabase.getItem(id);
            editName.setText(mItem.getItemName());
            editDescription.setText(mItem.getItemDescription());
        }

        btnSave.setOnClickListener(v -> {
            String itemName = editName.getText().toString();
            String description = editDescription.getText().toString();

            if (id != -1) {
                // Update existing item
                if (mInventoryDatabase.updateItem(id, itemName, description)) {
                    Toast.makeText(getContext(), R.string.item_updated_successfully, Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getContext(), R.string.failed_to_update_item, Toast.LENGTH_LONG).show();
                }
            }
            else {
                // Add new item to database
                long result = mInventoryDatabase.addItem(itemName, description, DEFAULT_QTY);
                if (result != -1) {
                    Toast.makeText(getContext(), R.string.item_added, Toast.LENGTH_LONG).show();
                    id = result; // get new item ID to pass back to details fragment
                }
                else {
                    Toast.makeText(getContext(), R.string.failed_to_add_item, Toast.LENGTH_LONG).show();
                }
            }
            // Prepare ID to send back to details view
            Bundle bundle = new Bundle();
            bundle.putLong("ITEM_ID", id);
            Navigation.findNavController(view).navigate(R.id.action_EditItemFragment_to_DetailsFragment, bundle);
        });

        btnDelete.setOnClickListener(v -> {
            if (id != -1) {
                // Deleting an item will trigger a confirmation dialog
                new AlertDialog.Builder(getContext())
                        .setTitle("Confirm Deletion")
                        .setMessage("Are you sure you want to delete this item?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            if (mInventoryDatabase.deleteItem(id)) {
                                Toast.makeText(getContext(), R.string.item_delete_successful, Toast.LENGTH_LONG).show();
                                Navigation.findNavController(view).navigate(R.id.action_EditItemFragment_to_MainGridFragment);
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
    }
}