package com.zybooks.inventoryappryanwardcs360;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.zybooks.inventoryappryanwardcs360.repo.InventoryDatabase;

public class NewAccountFragment extends Fragment {

    private InventoryDatabase mInventoryDatabase;

    public NewAccountFragment() {super(R.layout.fragment_new_account);}

    private EditText mEditUsername;
    private EditText mEditPassword;
    private EditText mConfirmEditPassword;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get singleton database
        mInventoryDatabase = InventoryDatabase.getInstance(requireContext());

        // Setup views and buttons - the first three are used in a method below
        mEditUsername = view.findViewById(R.id.editTextUsername);
        mEditPassword = view.findViewById(R.id.editTextPassword);
        mConfirmEditPassword = view.findViewById(R.id.editTextConfirmPassword);
        TextView mErrorText = view.findViewById(R.id.textview_error);
        Button mBtnCreateAccount = view.findViewById(R.id.button_create_account); // This button is only enabled when all text fields have a value

        mEditUsername.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (noFieldsEmpty()) {
                    mBtnCreateAccount.setEnabled(true);
                    // Clear error on text change
                    mErrorText.setText("");
                    mErrorText.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        mEditPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (noFieldsEmpty()) {
                    mBtnCreateAccount.setEnabled(true);
                    // Clear error on text change
                    mErrorText.setText("");
                    mErrorText.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        mConfirmEditPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (noFieldsEmpty()) {
                    mBtnCreateAccount.setEnabled(true);
                    // Clear error on text change
                    mErrorText.setText("");
                    mErrorText.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        mBtnCreateAccount.setOnClickListener(v -> {
            String username = mEditUsername.getText().toString();
            String password = mEditPassword.getText().toString();
            String confirmPassword = mConfirmEditPassword.getText().toString();

            // Text field validations
            if (!username.isEmpty() && mInventoryDatabase.userExists(username)) {
                mErrorText.setVisibility(View.VISIBLE);
                mErrorText.setText(R.string.user_already_exists);
            }
            else if (password.isEmpty() || confirmPassword.isEmpty()) {
                mErrorText.setVisibility(View.VISIBLE);
                mErrorText.setText(R.string.must_enter_password);
            }
            else if (!password.equals(confirmPassword)) {
                mErrorText.setVisibility(View.VISIBLE);
                mErrorText.setText(R.string.passwords_do_not_match);
            }
            else {
                if (mInventoryDatabase.addUser(username, password) == -1) {
                    Toast.makeText(getContext(), "Error: Unable to create account", Toast.LENGTH_LONG).show();
                }
                else {
                    // Navigate back to login on successful user creation
                    Toast.makeText(getContext(), "Account created successfully", Toast.LENGTH_LONG).show();
                    Navigation.findNavController(view).navigate(R.id.action_NewAccountFragment_to_LoginFragment);
                }
            }
        });
    }

    private boolean noFieldsEmpty() {
        // This functions check to make sure all the text fields have values
        return (
                !mEditUsername.getText().isEmpty() &&
                !mEditPassword.getText().isEmpty() &&
                !mConfirmEditPassword.getText().isEmpty()
                );
    }

}