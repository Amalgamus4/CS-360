/*
This app was created for SNHU CS360
Instructor: Matthew Heusser
Creator: Ryan Ward
Last updated: 18 October 2026
 */

package com.zybooks.inventoryappryanwardcs360.viewmodel;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventoryappryanwardcs360.R;


public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}