package com.zybooks.inventoryappryanwardcs360;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.zybooks.inventoryappryanwardcs360.repo.InventoryDatabase;

public class LoginFragment extends Fragment {

    private InventoryDatabase mInventoryDatabase;

    public LoginFragment() {super(R.layout.fragment_login);}

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get singleton database
        mInventoryDatabase = InventoryDatabase.getInstance(requireContext());

        // Setup views and buttons
        EditText mEditUsername = view.findViewById(R.id.editTextUsername);
        EditText mEditPassword = view.findViewById(R.id.editTextPassword);
        TextView mErrorText = view.findViewById(R.id.textview_error);
        Button mBtnLogin = view.findViewById(R.id.button_login);
        Button mBtnNewAccount = view.findViewById(R.id.button_new_account);

        // New account creation
        mBtnNewAccount.setOnClickListener(v -> {
            Navigation.findNavController(view).navigate(R.id.action_LoginFragment_to_NewAccountFragment);
        });

        mEditUsername.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mBtnLogin.setEnabled(s.length() > 0);
                // Clear error when text changed
                mErrorText.setText("");
                mErrorText.setVisibility(View.INVISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        mEditPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mBtnLogin.setEnabled(s.length() > 0);
                // Clear error when text changed
                mErrorText.setText("");
                mErrorText.setVisibility(View.INVISIBLE);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Login action
        mBtnLogin.setOnClickListener(v -> {
            String username = mEditUsername.getText().toString();
            String password = mEditPassword.getText().toString();

            // Error checks and warnings
            if (username.isEmpty()) {
                mErrorText.setVisibility(View.VISIBLE);
                mErrorText.setText(R.string.please_enter_username);
            }
            else if (password.isEmpty()) {
                mErrorText.setVisibility(View.VISIBLE);
                mErrorText.setText(R.string.please_enter_password);
            }
            else if (mInventoryDatabase.loginValid(username, password)) {
                // Proceed to main grid on successful login
                Navigation.findNavController(view).navigate(R.id.action_LoginFragment_to_MainGridFragment);
            }
            else {
                mErrorText.setVisibility(View.VISIBLE);
                mErrorText.setText(R.string.invalid_login);
            }
        });
    }
}