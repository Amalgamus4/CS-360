package com.zybooks.inventoryappryanwardcs360.model;

import androidx.annotation.NonNull;

public class InventoryItem {
    private long mId;
    private String mItemName;
    private String mItemDescription;
    private int mQuantity;

    public InventoryItem(@NonNull String name, String description) {
        mItemName = name;
        mItemDescription = description;
    }
    public InventoryItem(@NonNull String name, String description, int quantity) {
        mItemName = name;
        mItemDescription = description;
        mQuantity = quantity;
    }
    public InventoryItem(long id, @NonNull String name, String description, int quantity) {
        mId = id;
        mItemName = name;
        mItemDescription = description;
        mQuantity = quantity;
    }
    public InventoryItem(){}

    public long getId() { return mId; }
    public void setId(long id){
        mId = id;
    }
    public int getQuantity() { return mQuantity; }
    public String getItemName() { return mItemName; }
    public String getItemDescription(){
        return mItemDescription;
    }
    public void setItemName(String name){
        mItemName = name;
    }
    public void setItemDescription(String description){
        mItemDescription = description;
    }
    public void setQuantity(int quantity) { mQuantity = quantity; }
}
